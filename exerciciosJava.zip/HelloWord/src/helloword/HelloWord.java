/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package helloword;

import java.util.*;

/**
 * Comentario de criação de classe
 * @author Aluno CA Gabriel Schultes
 */
public class HelloWord {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Vamos começar nosso codigo
        
        
         Scanner scan = new Scanner(System.in);
         
         System.out.println("Escreva o primeiro valor: ");
        int valor1 = scan.nextInt();
        
        System.out.println("Escreva o segundo valor: ");
        int valor2 = scan.nextInt();
        
      
        scan.close();
        
         int valor3 = valor1;
         valor1 = valor2;
         valor2 = valor3;
       
        System.out.println("Valor 1 : " +valor1);
        System.out.println("Valor 2 : " + valor2);
        
        Date date = new Date();
        System.out.println(date);
         
        
        
        
        
        
        
        
         
        
        
    }
    
}
